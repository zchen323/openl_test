#!/bin/sh

java -Dopenl-cmd=run -classpath libs/*;openl/lib/* myOpenlTest.Main
